# Taskly UI/UX Prototype

Static, UI-only prototype for the assignment: Login, Dashboard, Add Task, Task List.

## Preview locally
Open `index.html` in a browser. No build tools or dependencies are required.

## Contents
- `index.html` — four screens and prototype structure
- `frontend/styles/theme.css` and `app.css` — shared theme and styling
- `frontend/app.js` — local screen switching and demo-only interactions
- `frontend/assets/monkey-login-original.png` — the supplied illustration, used as-is on login
- `docs/ui-ux/design-spec.md` — color, typography, screens, responsive notes

**No backend or authentication is implemented.** This is a visual prototype for UI/UX handoff.
