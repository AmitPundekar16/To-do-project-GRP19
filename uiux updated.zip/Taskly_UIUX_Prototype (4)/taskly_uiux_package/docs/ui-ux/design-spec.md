# Taskly UI/UX Design Specification (UI-only)

## Scope
Design prototype only: Login, Dashboard, Add Task, Task List. No API, backend, database, or real authentication/task persistence.

## Theme palette
- Forest green: `#355D3B`
- Deep forest: `#27472D`
- Leaf green: `#8BBE78`
- Banana gold: `#E5B943`
- Warm cream: `#F5F0DF`
- Main background: `#F5F7F2`
- Text: `#26362A`
- Muted text: `#7B887D`
- White surface: `#FFFFFF`

## Typography
System sans-serif stack; bold compact headings; readable body copy; labels and eyebrow text in uppercase with modest letter spacing.

## Screens
1. Login: original provided jungle illustration, floating sticker-like Taskly wordmark upper-left, Sign In and Sign Up floating pill stickers upper-right. Authentication modal is a visual mock; no auth connected.
2. Dashboard: task-stat cards, weekly progress visualization, today's focus list.
3. Add Task: title, description, due date, priority, status, save/cancel controls. Submit is mock-only.
4. Task List: search, status filter, sorting control, priority and status badges, complete/edit/delete affordances. Search and status filter work locally for prototype demonstration; no persistence.

## Responsive behavior
Sidebar becomes compact horizontal navigation on narrow screens; statistic cards reduce to two columns; task rows adapt; login overlay stickers stay positioned over the artwork.


## Updated direction
- Brand spelling: Taskly (capital T).
- Warm palette: cream, terracotta, caramel, amber, peach, and soft brown.
- The Login/Welcome landing page is the first screen on website launch.
- Floating Sign In and Sign Up sticker buttons overlay the original monkey image.
- This remains a UI-only prototype; submitting the demo form transitions to Dashboard.
